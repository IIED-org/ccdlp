This module allows you to collapse the "text format" or "input format" 
dropdowns to clean up the UI on a per-role basis. 

Configuration is easy. Administer your permissions at  /admin/people/permissions
and look for "Hide Input Formats". You may select to show text format dropdowns
for each of your roles. Deselect all roles to remove the dropdown selector.
