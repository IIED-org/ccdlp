ABOUT Image effect kit
--------------------------------------------------------------------------------

http://drupal.org/project/iek

Image Effect Kit provides image effects to be added to an image styles.
It includes the following effects:

- Border effect

- Rounded corner effect

- Padding effect

- Watermark effect

- Resizing effect

- Overlay effect

- Filter effect


REQUIREMENTS
--------------------------------------------------------------------------------
- PHP 5
- Image module and token module.
- GD library.


CONFIGURATION
--------------------------------------------------------------------------------
View and edit a sample image style
7.x: /admin/config/media/image-styles/edit/iek_photo
